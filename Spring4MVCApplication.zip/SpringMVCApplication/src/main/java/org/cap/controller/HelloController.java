package org.cap.controller;

import org.cap.model.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		String msg="Welcome To Spring4MVC";
		return new ModelAndView("hello", "message", msg);
	}
	
	@RequestMapping("/employee")
	public ModelAndView showEmployeeForm(){
		return new ModelAndView("employee", "emp", new Employee());
	}
	
	@RequestMapping("/showEmployee")
	public String showEmployee(@ModelAttribute("emp") Employee employee){
		System.out.println(employee);
		return "showemp";
	}
	
}
