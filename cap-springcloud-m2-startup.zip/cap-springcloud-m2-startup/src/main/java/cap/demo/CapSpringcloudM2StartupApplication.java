package cap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@SpringBootApplication
@EnableConfigServer
public class CapSpringcloudM2StartupApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapSpringcloudM2StartupApplication.class, args);
	}
}
